#question 1
def hms_en_secondes(h, m, s):
    return h * 3600 + m * 60 + s


heure = int(input("donner nb heures: "))

minute = int(input("donner nb minutes: "))

seconde = int(input("donner nb secondes: "))

resultat = hms_en_secondes(heure, minute, seconde)
print(resultat)

#question 2

def secondes_en_hms(secondes):
    h = secondes // 3600
    reste = secondes % 3600
    m = reste // 60
    s = reste % 60
    return h, m, s

nb_s = int(input("donner nb secondes a convertir"))
nb_heures, nb_minutes, nb_secondes = secondes_en_hms(nb_s)
print(nb_s, "-->", nb_heures, ":", nb_minutes, ":", nb_secondes)


def hms_en_secondes(h, m, s):
    return h * 3600 + m * 60 + s


def secondes_en_hms(secondes):
    h = secondes // 3600
    reste = secondes % 3600
    m = reste // 60
    s = reste % 60
    return h, m, s


#Questions 3

menu = "Que voulez-vous faire \n \
1) Convertir h:m:s en secondes \n \
2) Convertir secondes en h:m:s "

print(menu)
choix = int(input("Quel est votre choix?"))

if choix == 1:
    nb_heure = int(input("canner nb heures a convertir"))
    nb_minute = int(input("conner nb minute a convertir"))
    nh_secondes = int(input("cgnner nb secondes a convertir"))
    sec = hms_en_secondes(nb_heure, nb_minute, nb_secondes)
    print(nb_heure, ":", nb_minute, ":", nh_secondes, "-->", sec)

elif choix == 2:
    nb_sec = int(input("donner nb secondes a convertir"))
    nb_heure,nb_minute,nb_secondes = secondes_en_hms(nb_sec)
    print(nb_sec, "--->",nb_heure, ":", nb_minute, ":", nb_secondes)

else:
    print("mauyais choix")
