#la fontion suivante nous permet de calculer la longueur du chiffre

def longueurEntier(unNbre):
    nbChiffres=1
    base = 10
    while ((unNbre / base) >= 1):
        nbChiffres += 1
        base = base * 10
    return nbChiffres

nb = int(input('veuillez saisir un nombre de votre choix pour connaitre sa longeur'))
print(longueurEntier(nb))