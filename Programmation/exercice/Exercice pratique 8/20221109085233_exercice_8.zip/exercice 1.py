def ligneCar(n, ca):
   for i in range(0, n):
    print(ca, end=' ')
ligneCar (5, "test")
