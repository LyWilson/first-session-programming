import math


def surfCercle (r):
    return math.pi * (r**2)
print (surfCercle (2.5))
