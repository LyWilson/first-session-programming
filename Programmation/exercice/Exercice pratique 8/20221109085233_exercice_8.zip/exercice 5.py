def minuscules (chaine) :
   nbre_miuscules = 0
   for lettre in chaine:
     if lettre. islower () :
        nbre_miuscules = nbre_miuscules + 1
   return nbre_miuscules

ch = input ("donner une chaine de caracteres: ")
resultat =minuscules (ch)
print ("cette chaine contient ", resultat," miniscules")
print ("*"*10)


#def min_maj (chaine):
#   nbre_miuscules = 0
#  nbre_majuscules = 0
#   for lettre in chaine:
#     if lettre.islower () :
#       nbre_miuscules = nbre_miuscules + 1
#     elif lettre. isupper () :
#        nbre_majuscules = nbre_majuscules + 1
#   return nbre_miuscules, nbre_majuscules

#min, maj = min_maj (ch)
#print("cette chaine contient ", min, " miniscules")
#print("cette chaine contient ", maj, " majuscules")
