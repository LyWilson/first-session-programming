def bissextile (a):
   if a%4 == 0 and not (a%100 == 0) or a%400 == 0:
     return True
   return False
annee = int(input("Donnez une année:"))
biss = bissextile (annee)
if (biss == True):
   print (annee, "est bissextile")
else:
   print (annee, "n'est pas bissextile")
