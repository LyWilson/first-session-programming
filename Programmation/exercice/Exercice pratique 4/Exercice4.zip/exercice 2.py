from math import*
n=int(input("entrez nombre des eleves?"))
a=0
for i in range(0,n):
    i=int(input("la note"))
    a=a+i

print(a/n)


