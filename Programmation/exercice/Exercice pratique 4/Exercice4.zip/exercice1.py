while True:
    passe=input("Entrez votre mot de passe? ")
    if passe == "wow":
        print("Bienvenue")
        break
    else:
        print("mot de passe invalide")




