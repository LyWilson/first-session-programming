nb=int(input("Entrez un nombre entier"))
for i in range(0,nb):
    for a in range(0,i+1):
        print(" * ",end=(" "))
    print(" ")

nb2=int(input("Entrez un nombre entier"))
for b in range(0,nb2):
    for c in range(0,nb2-b):
        print(" * ",end=(" "))
    print(" ")